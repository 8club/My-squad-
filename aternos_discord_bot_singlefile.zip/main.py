
import asyncio
from discord.ext import commands
from playwright.async_api import async_playwright
import os

bot = commands.Bot(command_prefix="!")

DISCORD_TOKEN = "MTQwMDUwMTM3OTg4NTMwNTg5Nw.Guv7oD.Etc6P9a7Y5yJYzQzC_296xu_UfXYQt0ugkIBE0"
ATERNOS_USER = "dana635"
ATERNOS_PASS = "Dana@#$12"

@bot.event
async def on_ready():
    print(f"Bot is online as {bot.user}")

@bot.command()
async def start(ctx):
    await ctx.send("⏳ Starting Aternos server, please wait...")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        try:
            await page.goto("https://aternos.org/go/")
            await page.fill('input[name="user"]', ATERNOS_USER)
            await page.fill('input[name="password"]', ATERNOS_PASS)
            await page.click('button[type="submit"]')
            await page.wait_for_url("https://aternos.org/server/", timeout=15000)
            await page.click("#start")
            await ctx.send("✅ Start button clicked. Server starting!")
        except Exception as e:
            await ctx.send(f"❌ Error: {e}")
        finally:
            await browser.close()

bot.run(DISCORD_TOKEN)
